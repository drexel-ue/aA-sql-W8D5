require_relative '02_searchable'
require 'active_support/inflector'

# Phase IIIa
class AssocOptions
  attr_accessor(
    :foreign_key,
    :class_name,
    :primary_key
  )

  def model_class
    class_name.constantize
  end

  def table_name
    model_class.table_name
  end
end

class BelongsToOptions < AssocOptions
  def initialize(name, options = {})
    default = {
      foreign_key: (name.to_s + '_id').to_sym,
      class_name: name.to_s.camelcase,
      primary_key: :id,
    }
    default.each_pair do |key, val|
      self.send("#{key}=", options[key] || val)
    end
  end
end

class HasManyOptions < AssocOptions
  def initialize(name, self_class_name, options = {})
    default = {
      foreign_key: (self_class_name.to_s.downcase + '_id').to_sym,
      class_name: name.to_s.singularize.camelcase,
      primary_key: :id,
    }
    default.each_pair do |key, val|
      self.send("#{key}=", options[key] || val)
    end
  end
end

module Associatable
  # Phase IIIb
  
  def belongs_to(name, options = {})
    belongings = BelongsToOptions.new(name, options)
    self.assoc_options[name] = belongings
    define_method(name) do
      p_key = self.class.assoc_options[name].primary_key 
      f_key = belongings.foreign_key
      belongings.model_class.where(p_key => self.send(f_key)).first
    end
  end

  def has_many(name, options = {})
    belongings = HasManyOptions.new(name, self, options)
    define_method(name) do
      p_key = belongings.primary_key
      f_key = belongings.foreign_key
      belongings.model_class.where(f_key => self.send(p_key))
    end
  end

  def assoc_options
    @assoc_options ||= {}
  end

end

class SQLObject
  # Mixin Associatable here...
  extend Associatable
end
